
public class MyCalculator {

	public static void main(String[] args) {
		int x = 360;
		int y = 60;
		System.out.println(x + "+" + y + "=" + getCalculator('+').CalculatorInt(x, y));
		
		System.out.println(x + "-" + y + "=" + getCalculator('-').CalculatorInt(x, y));

		System.out.println(x + "*" + y + "=" + getCalculator('*').CalculatorInt(x, y));
		
		System.out.println(x + "/" + y + "=" + getCalculator('/').CalculatorInt(x, y));
	}
	
	static Calculator getCalculator(char operator) {
		//write your code here
	}
}
