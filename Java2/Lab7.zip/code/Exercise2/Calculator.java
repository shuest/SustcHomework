@FunctionalInterface
public interface Calculator {
	int CalculatorInt(int x, int y);
}
