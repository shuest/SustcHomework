@FunctionalInterface
public interface Info {
	void print();
}
